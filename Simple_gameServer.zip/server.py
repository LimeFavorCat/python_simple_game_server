import socket
from _thread import *
import random

server = "192.168.56.1"
port = 5555

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    s.bind((server, port))
except socket.error as e:
    str(e)

s.listen(2)
print("Waiting for a connection, Server Started")  # 서버 작동 시작

# 서버가 가지고 있는 게임 관련 변수.
pos = ["position,0,0", "position,0,0"]  # 플레이어 각각의 초기화
player_pos = [[0, 2], [-100,-100]]
player_exited = 0


def read_pos(msg, p1):
    # 플레이어로부터 입력받은 메세지를 분석하고 서버의 대응을 결정하는 함수
    # str[문자열 변수]: 플레이어의 입력   |   p1[정수형 변수]: 메세지를 보낸 플레이어의 번호
    global player_exited, player_pos, pos
    p2 = (p1 + 1) % 2
    print("[", str(p1), "] Received: ", msg)  # 출력 예시 [ 0 ] Received: finish,0,1,0
    temp = msg.split(",")
    # 메세지의 종류를 파악
    # 클라이언트에서는
    # n.send("[메세지의 종류],[전달하고 싶은 데이터],[데이터],[데이터]") 와 같은 명령어를 이용해 데이터를 서버에 전송할 수 있다.
    try:
        if player_exited:
            return "you_win"
        else:
            if temp[0] == "exit":
                player_exited = 1
                return "you_lose"
            elif temp[0] == "position":
                player_pos[p1][0] = int(temp[1])
                player_pos[p1][1] = int(temp[2])
                p2pos = "position," + str(player_pos[p2][0]) + "," + str(player_pos[p2][1])
                return p2pos
            else:
                return "none"
    except:
        print("Lost connection")
        conn.close()
        return "error"


def make_pos(tup):
    return str(tup[0]) + "," + str(tup[1])


def threaded_client(conn, player):  # 클라이언트 각각에 대해 실행된다.

    # 각각의 클라이언트에 대한 초기화 부분
    global player_exited
    conn.send(str.encode(pos[player]))  # 연결이 완료된 플레이어에게 초기화 정보를 전송
    print(pos[player])
    reply = ""

    while True:  # 메세지 반복 확인 및 read_pos 함수에서 결정한 반응 보내기
        try:
            reply = read_pos(conn.recv(2048).decode(), player)
        except:
            print("lost connection")
            conn.close()

        print("[", str(player), "]", "Sending : ", reply)  # 출력 예시 [ 1 ] Send: you_win
        conn.sendall(reply.encode('utf-8'))


# ============================================================================================ 실제 서버가 실행되는 부분


currentPlayer = 0
while True:
    conn, addr = s.accept()
    print("Connected to:", addr, currentPlayer)

    start_new_thread(threaded_client, (conn, currentPlayer))
    currentPlayer += 1
