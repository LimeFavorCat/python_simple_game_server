import pygame
from network import Network
import ctypes
import time

screen_width = 800  # 화면 너비
screen_height = 500  # 화면 높이
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Simple game")  # 윈도우 창 이름

fullScreen = 0  # 전체화면 여부 (1인 경우만 전체화면)
bgImage = "image/background.png"  # 배경
bgMusic = "background_music.mp3"  # 배경음악
bgVolume = 0.1  # 배경음악 볼륨 (0~1 사이의 크기)

pygame.init()
pygame.mixer.init()
pygame.mixer.music.load(bgMusic)
pygame.mixer.music.play(-1, 0.0)
pygame.mixer.music.set_volume(bgVolume)
clock = pygame.time.Clock()

clientNumber = 0

shieldBash_sound = pygame.mixer.Sound("Sound/shield_bash.wav")
win_sound = pygame.mixer.Sound("Sound/win.wav")
lose_sound = pygame.mixer.Sound("Sound/lose.wav")
death_sound = pygame.mixer.Sound("Sound/death.wav")

# 이미지 파일들
# 변수 이름 = pygame.image.load("파일경로")
background_image = pygame.image.load("image/background.png")
winLose_image = [pygame.image.load("image/Final_lose.png"), pygame.image.load("image/Final_win.png")]
message_image = [pygame.image.load("image/error_atk.png"), pygame.image.load("image/error_def.png"),
                 pygame.image.load("image/error_less.png"), pygame.image.load("image/error_over.png"),
                 pygame.image.load("image/error_wait.png"), pygame.image.load("image/error_waiting.png")]

player_image = [[pygame.image.load("image/player_1.png"), pygame.image.load("image/player_1.png")],
                [pygame.image.load("image/player_2.png"), pygame.image.load("image/player_2.png")]]

# 게임에 필요한 변수들

run = 1


class Player():
    def __init__(self, x, y, character, state):
        # 플레이어의 속성들
        self.x = x
        self.y = y
        self.character = character
        self.state = state

    def move(self, speed):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            if self.x > 0:
                self.x -= speed

        if keys[pygame.K_RIGHT]:
            if self.x < screen_width - 100:
                self.x += speed

        if keys[pygame.K_UP]:
            if self.y > 0:
                self.y -= speed

        if keys[pygame.K_DOWN]:
            if self.y < screen_height - 100:
                self.y += speed

    def draw(self, screen):
        screen.blit(player_image[self.character][self.state], (self.x, self.y))


def game_AskServer(network, task):
    receive = network.send(str(task))
    temp = (str(receive)).split(",")

    if temp[0] == "you_win":
        game_Result(screen, 1)
        return "win"
    elif temp[0] == "you_lose":
        game_Result(screen, 0)
        return "lose"
    elif temp[0] == "position":
        return int(temp[1]), int(temp[2])
    else:
        return receive


def game_DrawScreen(screen, player, player2):
    # 배경 표시
    screen.blit(background_image, (0, 0))

    # 플레이어 표시
    if int(player.y) < player2.y:
        player.draw(screen)
        player2.draw(screen)
    else:
        player2.draw(screen)
        player.draw(screen)

    # 기타 사항 표시

    # 화면 그리기
    pygame.display.update()


def game_Result(screen, result):
    screen.blit(winLose_image[result], (0, 0))
    game_Sound(result + 2)
    pygame.display.update()
    timer = time.time()
    while True:
        if (time.time() - timer) > 2:
            global run
            run = False
            pygame.quit()
            quit()
            break


def game_Sound(sound):
    if sound == 1:
        pygame.mixer.Sound.play(shieldBash_sound)
    elif sound == 3:
        pygame.mixer.Sound.play(win_sound)
    elif sound == 2:
        pygame.mixer.Sound.play(lose_sound)


def game_Message(screen, msg):
    if msg != -1:
        screen.blit(message_image[msg], (0, 0))


def main():
    # 초기화
    global run, clock
    systemMessage = -1
    run = True
    n = Network()

    # 각 플레이어 초기 위치 설정
    temp = str(n.getPos()).split(",")
    p = Player(int(temp[1]), int(temp[2]), 0, 0)
    p2 = Player(-100, -100, 1, 0)
    player = [p, p2]


    # 전체화면

    if fullScreen == 1:
        user32 = ctypes.windll.user32
        screensize = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
        pygame.display.set_mode(screensize, pygame.FULLSCREEN)

    while run:

        clock.tick(60)
        game_Message(screen, systemMessage)

        p1Pos = "position," + str(p.x) + "," + str(p.y)
        p2Pos = game_AskServer(n, p1Pos)
        p2.x = p2Pos[0]
        p2.y = p2Pos[1]

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_AskServer(n, "exit")
                game_Result(screen, 0)

        p.move(5)
        game_DrawScreen(screen, p, p2)


main()
