from typing import List

import pygame
from network import Network
import ctypes
import time

screen_width = 1920  # 화면 너비
screen_height = 1080  # 화면 높이
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Knight VS Knight")  # 윈도우 창 이름

clientNumber = 0
# 배경음악
pygame.init()
pygame.mixer.init()
pygame.mixer.music.load("FunnyToy.mp3")
pygame.mixer.music.play(-1, 0.0)
pygame.mixer.music.set_volume(0.2)
sword_sound = pygame.mixer.Sound("Sound/sword.wav")
shield_sound = pygame.mixer.Sound("Sound/shield.wav")
walk_sound = pygame.mixer.Sound("Sound/walk.wav")
clash_sound = pygame.mixer.Sound("Sound/clash.wav")
shieldBash_sound = pygame.mixer.Sound("Sound/shield_bash.wav")
win_sound = pygame.mixer.Sound("Sound/win.wav")
lose_sound = pygame.mixer.Sound("Sound/lose.wav")
death_sound = pygame.mixer.Sound("Sound/death.wav")
"""
Music provided by https://eoun.com
Track: andrew - Funny Toy
Watch: https://youtu.be/LP2Y_Im8LDs
Free Download: https://eoun.com/track/funny-toy

--- For online videos, YouTube, Facebook, Instagram, Vimeo, 
"""
# 이미지 파일들
# 변수 이름 = pygame.image.load("파일경로")
effect_image = [pygame.image.load("image/effect_1.png"), pygame.image.load("image/p1_r_idle.png")]
round_image = [[pygame.image.load("image/lose_round.png"), pygame.image.load("image/win_round.png"), pygame.image.load("image/start_round.png")],
               [pygame.image.load("image/round1.png"), pygame.image.load("image/round2.png"), pygame.image.load("image/round3.png")]]

player_image = [[[pygame.image.load("image/p2_r_idle.png"), pygame.image.load("image/p2_l_idle.png")],
                 [pygame.image.load("image/p2_r_s1.png"), pygame.image.load("image/p2_l_s1.png")],
                 [pygame.image.load("image/p2_r_s2.png"), pygame.image.load("image/p2_l_s2.png")],
                 [pygame.image.load("image/p2_r_s3.png"), pygame.image.load("image/p2_l_s3.png")],
                 [pygame.image.load("image/p2_r_a1.png"), pygame.image.load("image/p2_l_a1.png")],
                 [pygame.image.load("image/p2_r_a2.png"), pygame.image.load("image/p2_l_a2.png")],
                 [pygame.image.load("image/p2_r_a3.png"), pygame.image.load("image/p2_l_a3.png")],
                 [pygame.image.load("image/p2_death.png"), pygame.image.load("image/p2_stuned.png")],
                 ],[[pygame.image.load("image/p1_r_idle.png"), pygame.image.load("image/p1_l_idle.png")],
                 [pygame.image.load("image/p1_r_s1.png"), pygame.image.load("image/p1_l_s1.png")],
                 [pygame.image.load("image/p1_r_s2.png"), pygame.image.load("image/p1_l_s2.png")],
                 [pygame.image.load("image/p1_r_s3.png"), pygame.image.load("image/p1_l_s3.png")],
                 [pygame.image.load("image/p1_r_a1.png"), pygame.image.load("image/p1_l_a1.png")],
                 [pygame.image.load("image/p1_r_a2.png"), pygame.image.load("image/p1_l_a2.png")],
                 [pygame.image.load("image/p1_r_a3.png"), pygame.image.load("image/p1_l_a3.png")],
                 [pygame.image.load("image/p1_death.png"), pygame.image.load("image/p1_stuned.png")],
                 ]
                ]
background = pygame.image.load("image/Back.png")
anim_back = pygame.image.load("image/Back_anim.png")
floor = pygame.image.load("image/land.png")
card_image = [pygame.image.load("image/closed.png"), pygame.image.load("image/open.png"),
              pygame.image.load("image/up.png"),
              pygame.image.load("image/right.png"), pygame.image.load("image/down.png"),
              pygame.image.load("image/left.png"),
              pygame.image.load("image/sword.png"), pygame.image.load("image/shield.png")]
msg_image = [pygame.image.load("image/error_atk.png"), pygame.image.load("image/error_def.png"),
             pygame.image.load("image/error_less.png"), pygame.image.load("image/error_over.png"),
             pygame.image.load("image/error_wait.png"), pygame.image.load("image/error_waiting.png")]
result_image = [pygame.image.load("image/none.png"), pygame.image.load("image/win.png"),
                pygame.image.load("image/lose.png")]
act_image = [pygame.image.load("image/count_a.png"), pygame.image.load("image/count_d.png")]

winLose_image = [pygame.image.load("image/Final_win.png"), pygame.image.load("image/Final_lose.png")]
# 게임에 필요한 변수들
system_message = -1
wins = [0, 0, 0]
set_round = 0
tilemap = [[0, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 0]
           ]

cards = [0, 0, 0, 0, 0, 0, 0, 0]
p2_cards = [0, 0, 0, 0, 0, 0, 0, 0]
you_win = 0


class Player():
    def __init__(self, x, y, color, state, rotate):
        # 플레이어의 속성들
        self.x = x
        self.y = y
        self.color = color
        self.state = state
        self.rotate = rotate

    def draw(self, screen):
        # pygame.draw.rect(win, self.color, self.rect)
        screen.blit(player_image[self.color][0][self.rotate], (144 + 210 * self.x, -141 + 147 * self.y))


def react_msg(msg):
    # you_win / start_anim / start_check / wait / online
    msg = str(msg)
    temp = msg.split(",")
    if temp[0] == "you_win":
        global you_win
        if you_win != 1:
            winLose(screen, 0)
            you_win = 1

    elif temp[0] == "start_anim":
        global p2_cards
        p2_cards = [int(temp[1]), int(temp[2]), int(temp[3]), int(temp[4]), int(temp[5]), int(temp[6]), int(temp[7]),
                    int(temp[8])]

        return "start_anim"
    elif temp[0] == "start_check":

        if temp[1] == "0":
            return "start_check"
        else:
            tilemap[int(temp[2])][int(temp[3])] = 1
            return "start_check"
    elif temp[0] == "position":
        return int(temp[1]), int(temp[2])
    else:
        return temp[0]


def askServer(network, task, data="Nodata"):
    if data == "Nodata":
        temp = react_msg(network.send(str(task)))
        return temp
    else:
        temp = react_msg(network.send(str(task + data)))
        return temp


def cardFinish(tup):
    temp = "cardFinish," + str(tup[0]) + "," + str(tup[1]) + "," + str(tup[2]) + "," + str(tup[3]) + "," + str(
        tup[4]) + "," + str(tup[5]) + "," + str(tup[6]) + "," + str(tup[7])
    return temp


def redrawWindow(screen, player, player2, sword=0, shield=0):
    screen.blit(background, (0, 0))
    # 바닥 표시
    for i in range(5):
        for j in range(6):
            if tilemap[i][j] != 2:
                screen.blit(floor, (349 + 210 * j, 99 + 147 * i))

    # 카드 이미지 표시
    for i in range(8):
        screen.blit(card_image[cards[i]], (400 + 125 * i, 883))
    # 에러 메세지 표시
    if system_message != -1:
        screen.blit(msg_image[system_message], (0, 0))
    # 승패 전적 표시
    for i in range(3):
        screen.blit(result_image[wins[i]], (1550 + 110 * i, 900))
        if sword > i:
            screen.blit(act_image[0], (150 + 70 * i, 910))
        if shield > i:
            screen.blit(act_image[1], (150 + 70 * i, 970))
    if player.y == 'o':
        player.y = 0
    if int(player.y) < player2.y:
        player.draw(screen)
        player2.draw(screen)
    else:
        player2.draw(screen)
        player.draw(screen)

    pygame.display.update()


def winLose(screen, isWin):
    screen.blit(winLose_image[isWin], (0, 0))
    pygame.display.update()



def anim_dead(x, y, card, color):
    if card == 2:
        screen.blit(player_image[color][7][0],
                    (144 + 210 * x, -141 + 147 * y - 3 * 25))
    elif card == 3:
        screen.blit(player_image[color][7][0],
                    (144 + 210 * x + 105, -141 + 147 * y))
    elif card == 4:
        screen.blit(player_image[color][7][0],
                    (144 + 210 * x, -141 + 147 * y + 3 * 25))
    elif card == 5:
        screen.blit(player_image[color][7][0],
                    (144 + 210 * x - 105, -141 + 147 * y))
    elif card == 6:
        screen.blit(player_image[color][7][0],
                    (144 + 210 * x, -141 + 147 * y))
    elif card == 7:
        screen.blit(player_image[color][7][0],
                    (144 + 210 * x, -141 + 147 * y))
    elif card == 0:
        screen.blit(player_image[color][7][0],
                    (144 + 210 * x, -141 + 147 * y))


def define_Target(p, card):
    if card < 6:
        target = [p.x + (card == 3) - (card == 5), p.y - (card == 2) + (card == 4)]
    elif card == 6:
        target = [p.x - 1 + (p.rotate == 0) * 2, p.y]  # 바라보고 있는 칸
    else:
        target = [p.x, p.y]
    return target

def anim_Sound(type):

    if type < 6:
        pygame.mixer.Sound.play(walk_sound)
    elif type == 6:
        pygame.mixer.Sound.play(sword_sound)
    elif type == 7:
        pygame.mixer.Sound.play(shield_sound)
    elif type == 8:
        pygame.mixer.Sound.play(death_sound)
    elif type == 10:
        pygame.mixer.Sound.play(shieldBash_sound)
    elif type == 11:
        pygame.mixer.Sound.play(clash_sound)
    elif type == 12:
        pygame.mixer.Sound.play(win_sound)
    elif type == 13:
        pygame.mixer.Sound.play(lose_sound)


def anim_background():
    screen.blit(anim_back, (0, 0))
    for i in range(8):
        screen.blit(card_image[cards[i]], (10 + 100 * i, 920))
        screen.blit(card_image[p2_cards[i]], (1050 + 100 * i, 920))

    for i in range(5):
        for j in range(6):
            if int(tilemap[i][j]) != 2:
                screen.blit(floor, (349 + 210 * j, 99 + 147 * i))


# 8,0 = death / 8,1 = stun
# state 0:idle 1: stun , 2345 : move , 6:atk, 7:def, 8:death , 9:restart , 10 shield
def anim_character(frame, player):  # frame : 0~25, 25~50
    if frame < 26:
        if player.state == 0:  # stun
            screen.blit(player_image[player.color][7][1],
                        (144 + 210 * player.x, -141 + 147 * player.y))
        elif player.state == 2:
            screen.blit(player_image[player.color][0][player.rotate],
                        (144 + 210 * player.x, -141 + 147 * player.y - 3 * frame))
        elif player.state == 3:
            screen.blit(player_image[player.color][0][0],
                        (144 + 210 * player.x + int(4.2 * frame), -141 + 147 * player.y))
        elif player.state == 4:
            screen.blit(player_image[player.color][0][player.rotate],
                        (144 + 210 * player.x, -141 + 147 * player.y + 3 * frame))
        elif player.state == 5:
            screen.blit(player_image[player.color][0][1],
                        (144 + 210 * player.x - int(4.2 * frame), -141 + 147 * player.y))
        elif player.state == 6:
            screen.blit(player_image[player.color][4 + frame // 12][player.rotate],
                        (144 + 210 * player.x, -141 + 147 * player.y))
        elif player.state == 7:
            screen.blit(player_image[player.color][1 + frame // 15][player.rotate],
                        (144 + 210 * player.x, -141 + 147 * player.y))
    else:
        if player.state == 0:  # stun
            screen.blit(player_image[player.color][7][1],
                        (144 + 210 * player.x, -141 + 147 * player.y))
        elif player.state == 1:  # idle
            screen.blit(player_image[player.color][0][player.rotate],
                        (144 + 210 * player.x, -141 + 147 * player.y))
        elif player.state == 2:
            screen.blit(player_image[player.color][0][player.rotate],
                        (144 + 210 * player.x, -141 + 147 * player.y - 3 * frame))
        elif player.state == 3:
            screen.blit(player_image[player.color][0][0],
                        (144 + 210 * player.x + int(4.2 * frame), -141 + 147 * player.y))
        elif player.state == 4:
            screen.blit(player_image[player.color][0][player.rotate],
                        (144 + 210 * player.x, -141 + 147 * player.y + 3 * frame))
        elif player.state == 5:
            screen.blit(player_image[player.color][0][1],
                        (144 + 210 * player.x - int(4.2 * frame), -141 + 147 * player.y))
        elif player.state == 6:
            screen.blit(player_image[player.color][4 + (frame - 25) // 12][player.rotate],
                        (144 + 210 * player.x, -141 + 147 * player.y))
        elif player.state == 7:
            screen.blit(player_image[player.color][2][player.rotate],
                        (144 + 210 * player.x, -141 + 147 * player.y))
        elif player.state == 9:  # restart
            if frame % 2 != 0:
                screen.blit(player_image[player.color][0][player.rotate],
                            (144 + 210 * player.x, -141 + 147 * player.y))
        elif player.state == 10:  # shield
            if frame < 40:
                screen.blit(player_image[player.color][3][player.rotate],
                            (144 + 210 * player.x, -141 + 147 * player.y))
            else:
                screen.blit(player_image[player.color][0][player.rotate],
                            (144 + 210 * player.x, -141 + 147 * player.y))


def main():


    # 초기화
    global set_round, system_message, cards, p2_cards, tilemap, wins
    run = True
    n = Network()

    startPos = react_msg(n.getPos())
    clock = pygame.time.Clock()

    # 맵 초기화
    p = Player(startPos[0], startPos[1], 0, 0, 0)
    if startPos[0] == 0:
        p2 = Player(5, 2, 1, 0, 1)
    else:
        p2 = Player(0, 2, 1, 0, 0)
        p.rotate = 1

    floor_xy = [6, 5]
    wins = [0, 0, 0]
    set_round = 0
    tilemap = [[0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0]
               ]
    # 전체화면

    user32 = ctypes.windll.user32
    screensize = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    pygame.display.set_mode(screensize, pygame.FULLSCREEN)


    while run:
        # 한 턴 시작
        if set_round < 8:
            set_round += 1
        target = 0
        sword = (set_round + 2) // 4
        shield = set_round // 4
        cards = [0, 0, 0, 0, 0, 0, 0, 0]
        for i in range(8):
            if set_round > i:
                cards[i] = 1
        redrawWindow(screen, p, p2, sword, shield)
        p1_confirmed = 0
        p2_confirmed = 0

        # 입력 대기
        while True:
            clock.tick(30)
            if p1_confirmed == 1:
                temp = askServer(n, cardFinish(cards))
                if temp == "start_anim":
                    break
                for event in pygame.event.get():  # 종료 확인
                    if event.type == pygame.QUIT:
                        if you_win:
                            run = False
                            pygame.quit()
                            quit()
                            break
                        else:
                            print("exit_pressed")
                            askServer(n, "playerExit")
                            winLose(screen, 1)
                            timer = time.time()
                        while True:
                            if (time.time() - timer) > 1:
                                run = False
                                pygame.quit()
                                quit()
                                break
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_F4:
                            if you_win:
                                run = False
                                pygame.quit()
                                quit()
                                break
                            else:
                                print("exit_pressed")
                                askServer(n, "playerExit")
                                winLose(screen, 1)
                                timer = time.time()
                            while True:
                                if (time.time() - timer) > 1:
                                    run = False
                                    pygame.quit()
                                    quit()
                                    break
                        elif event.key == pygame.K_ESCAPE or event.key == pygame.K_r:
                            askServer(n, "cardRefresh")
                            target = 0
                            sword = (set_round + 2) // 4
                            shield = set_round // 4
                            for i in range(set_round):
                                cards[i] = 1
                            if system_message != 5:
                                system_message = -1
                            p1_confirmed = 0
                            redrawWindow(screen, p, p2, sword, shield)

            else:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        if you_win:
                            run = False
                            pygame.quit()
                            quit()
                            break
                        else:
                            print("exit_pressed")
                            askServer(n, "playerExit")
                            winLose(screen, 1)
                            timer = time.time()
                        while True:
                            if (time.time() - timer) > 1:
                                run = False
                                pygame.quit()
                                quit()
                                break
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_F4:
                            if you_win:
                                run = False
                                pygame.quit()
                                quit()
                                break
                            else:
                                print("exit_pressed")
                                askServer(n, "playerExit")
                                winLose(screen, 1)
                                timer = time.time()
                            while True:
                                if (time.time() - timer) > 1:
                                    run = False
                                    pygame.quit()
                                    quit()
                                    break
                        elif event.key == pygame.K_ESCAPE or event.key == pygame.K_r:
                            target = 0
                            sword = (set_round + 2) // 4
                            shield = set_round // 4
                            for i in range(set_round):
                                cards[i] = 1
                            if system_message != 5:
                                system_message = -1
                            p1_confirmed = 0
                            redrawWindow(screen, p, p2, sword, shield)
                        elif event.key == pygame.K_TAB:  # 확인
                            if target == set_round:
                                system_message = 4
                                p1_confirmed = 1
                                redrawWindow(screen, p, p2, sword, shield)
                            else:
                                system_message = 2
                                redrawWindow(screen, p, p2, sword, shield)
                        elif target < set_round:  # 카드 입력 확인.
                            current_card = 0
                            if event.key == pygame.K_UP:
                                current_card = 2
                            elif event.key == pygame.K_RIGHT:
                                current_card = 3
                            elif event.key == pygame.K_DOWN:
                                current_card = 4
                            elif event.key == pygame.K_LEFT:
                                current_card = 5
                            elif event.key == pygame.K_z:
                                if sword > 0:
                                    sword -= 1
                                    current_card = 6
                                else:
                                    system_message = 0
                                    redrawWindow(screen, p, p2, sword, shield)
                            elif event.key == pygame.K_x:
                                if shield > 0:
                                    shield -= 1
                                    current_card = 7
                                else:
                                    system_message = 1
                                    redrawWindow(screen, p, p2, sword, shield)
                            if current_card != 0:  # 카드 입력 처리.
                                cards[target] = current_card
                                target += 1
                                if system_message != 5:
                                    system_message = -1
                                redrawWindow(screen, p, p2, sword, shield)
                result = askServer(n, "cardCheck")
                if result == "isFinished":
                    if system_message == -1:
                        system_message = 5
                    redrawWindow(screen, p, p2, sword, shield)
                elif result == "wait":
                    if system_message == 5:
                        system_message = -1
                    redrawWindow(screen, p, p2, sword, shield)


        # 에니메이션 시작
        # 카드 2:위 , 3:오른쪽 , 4:아래 , 5:왼쪽 , 6:공격 , 7:방어
        # pygame.display.update()
        system_message = -1
        first_pos = [[p.x, p.y], [p2.x, p2.y]]
        # 각각의 카드별로 애니메이션 진행
        for i in range(set_round):

            target = [define_Target(p, cards[i]), define_Target(p2, p2_cards[i])]
            nextpos = target
            if cards[i] == 6:
                nextpos[0][0] = p.x
                nextpos[0][1] = p.y
            if p2_cards[i] == 6:
                nextpos[1][0] = p2.x
                nextpos[1][1] = p2.y

            for event in pygame.event.get():  # 종료 확인
                if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_F4):
                    if you_win:
                        run = False
                        pygame.quit()
                        quit()
                        break
                    else:
                        print("exit_pressed")
                        askServer(n, "playerExit")
                        winLose(screen, 1)
                        timer = time.time()
                    while True:
                        if (time.time() - timer) > 1:
                            run = False
                            pygame.quit()
                            quit()
                            break

            # 쳐다보고 있는 방향 결정 및 적용.
            if p.x >= p2.x:
                p.rotate = 1
                p2.rotate = 0
            else:
                p.rotate = 0
                p2.rotate = 1

            p.state = cards[i]
            p2.state = p2_cards[i]
            print(" 1 frame state : ", p.state, p2.state)
            anim_Sound(p.state)
            anim_Sound(p2.state)
            for frame in range(1, 26):
                clock.tick(100)
                anim_background()
                if p.y < p2.y:
                    anim_character(frame, p)
                    anim_character(frame, p2)
                else:
                    anim_character(frame, p2)
                    anim_character(frame, p)
                pygame.display.update()
            # 전반부 에니메이션 종료 및 판정 시작
            effect = -1
            print(target)
            if cards[i] == 0:
                p.state = 1
            elif p2_cards[i] == 0:
                p2.state = 1
            if cards[i] < 6:
                if target[0][0] < 0 or target[0][0] > 5 or target[0][1] < 0 or target[0][1] > 4:
                    p.state = 8
                elif tilemap[target[0][1]][target[0][0]] != 0:
                    p.state = 8
                elif p2_cards[i] == 7:  # 상대방의 방패 쪽으로 이동하려 할때.
                    if target[0][0] == p2.x and target[0][1] == p2.y:
                        p2.state = 10
                        p.state = 0
            if p2_cards[i] < 6:
                if target[1][0] < 0 or target[1][0] > 5 or target[1][1] < 0 or target[1][1] > 4:
                    p2.state = 8
                elif tilemap[target[1][1]][target[1][0]] != 0:
                    p2.state = 8
                elif cards[i] == 7:  # 상대방의 방패 쪽으로 이동하려 할때.
                    if target[1][0] == p.x and target[1][1] == p.y:
                        # stun
                        p.state = 10
                        p2.state = 0

            if p.state == 8:
                if p2.state == 8:
                    p.state = p2.state = 9
            elif p2.state != 8:
                if cards[i] == p2_cards[i]:  # 둘의 동작이 같을경우
                    if cards[i] == 6:
                        if define_Target(p, cards[i]) == [p2.x, p2.y]:  # 칼이 부딛히면
                            effect = 0
                            anim_Sound(11)

                elif cards[i] == 6 or p2_cards[i] == 6:  # 한쪽만 공격
                    if p2.y == p.y and abs(p.x - p2.x) == 1:
                        if p2_cards[i] == 6:
                            if cards[i] == 7:
                                p.state = 10
                                p2.state = 0
                            else:
                                p.state = 8
                        else:
                            if p2_cards[i] == 7:
                                p2.state = 10
                                p.state = 0
                            else:
                                p2.state = 8
                    else:
                        if target[1][0] == p.x and target[1][1] == p.y:
                            p.state = p2.state = 9
                            tilemap[int(target[0][1])][int(target[0][0])] = 2
                            temp = "collapse," + str(target[1][1]) + "," + str(target[1][0])
                            askServer(n, temp)
                            print("같은 블럭으로 이동")
                            p.state = p2.state = 9
                        elif target[0][0] == p2.x and target[0][1] == p2.y:
                            p.state = p2.state = 9
                            tilemap[int(target[0][1])][int(target[0][0])] = 2
                            temp = "collapse," + str(target[0][1]) + "," + str(target[0][0])
                            askServer(n, temp)
                            print("같은 블럭으로 이동")
                            p.state = p2.state = 9

                elif (cards[i] < 6) + (p2_cards[i] < 6) == 2:  # 같은 블럭으로 이동
                    if target[0][0] == target[1][0] and target[0][1] == target[1][1]:
                        tilemap[int(target[0][1])][int(target[0][0])] = 2
                        temp = "collapse,"+str(target[0][1])+","+str(target[0][0])
                        askServer(n, temp)
                        print("같은 블럭으로 이동")
                        p.state = p2.state = 9
            anim_Sound(p.state)
            anim_Sound(p2.state)
            print(" 2 frame state : ", p.state, p2.state)
            for frame in range(26, 51):
                clock.tick(100)
                anim_background()
                if p.state == 8:
                    anim_dead(p.x, p.y, cards[i], p.color)
                    anim_character(frame, p2)
                    pygame.display.update()
                elif p2.state == 8:
                    anim_dead(p2.x, p2.y, p2_cards[i], p2.color)
                    anim_character(frame, p)
                    pygame.display.update()
                else:
                    if p.y < p2.y:
                        anim_character(frame, p)
                        anim_character(frame, p2)
                    else:
                        anim_character(frame, p2)
                        anim_character(frame, p)

                    pygame.display.update()
            if p.state == 8 or p2.state == 8:
                break
            elif p.state == 9:
                p.x = first_pos[0][0]
                p.y = first_pos[0][1]
                p2.x = first_pos[1][0]
                p2.y = first_pos[1][1]
                if p.x >= p2.x:
                    p.rotate = 1
                    p2.rotate = 0
                else:
                    p.rotate = 0
                    p2.rotate = 1

                if tilemap[p.y][p.x] != 0:
                    anim_Sound(8)
                    p.state = 8
                    anim_dead(p.x, p.y, cards[i], p.color)
                    anim_character(frame, p2)
                    pygame.display.update()
                elif tilemap[p2.y][p2.x] != 0:
                    anim_Sound(8)
                    p2.state = 8
                    anim_dead(p2.x, p2.y, p2_cards[i], p2.color)
                    anim_character(frame, p)
                    pygame.display.update()
                break
            if not p.state == 0:
                p.x = nextpos[0][0]
                p.y = nextpos[0][1]
            else:
                cards[i + 1] = 0
            if not p2.state == 0:
                p2.x = nextpos[1][0]
                p2.y = nextpos[1][1]
            else:
                p2_cards[i + 1] = 0

        # 에니메이션 재생이 끝남
        print("animation_finished")
        if p.state == 8 or p2.state == 8:
            if p.state == 8:  # 이번 라운드에서 패배함
                print("set lose")
                anim_Sound(13)
                for i in range(3):
                    if wins[i] == 0:
                        wins[i] = 2
                        screen.blit(round_image[1][i], (0, 500))
                        screen.blit(round_image[0][0], (1000, 500))
                        pygame.display.update()
                        break
                    elif wins[i] == 2:
                        pygame.display.update()
                        askServer(n, "animFinish,3")
                        winLose(screen, 1)
                        timer = time.time()
                        while True:
                            if (time.time() - timer) > 1:
                                run = False
                                pygame.quit()
                                quit()
                                break
            else:  # 이번 라운드에서 승리함
                print("set win")
                anim_Sound(12)
                for i in range(3):
                    if wins[i] == 0:
                        wins[i] = 1
                        screen.blit(round_image[1][i], (0, 500))
                        screen.blit(round_image[0][1], (1000, 500))
                        pygame.display.update()
                        break
                    elif wins[i] == 1:
                        pygame.display.update()
                        askServer(n, "animFinish,2")
                        winLose(screen, 0)
                        timer = time.time()
                        while True:
                            if (time.time() - timer) > 1:
                                run = False
                                pygame.quit()
                                quit()
                                break
            p = Player(startPos[0], startPos[1], 0, 0, 0)
            print(startPos)
            if startPos[0] == 0:
                p2 = Player(5, 2, 1, 0, 1)
            else:
                p2 = Player(0, 2, 1, 0, 0)
                p.rotate = 1

            floor_xy = [6, 5]
            set_round = 0
            tilemap = [[0, 0, 0, 0, 0, 0],
                       [0, 0, 0, 0, 0, 0],
                       [0, 0, 0, 0, 0, 0],
                       [0, 0, 0, 0, 0, 0],
                       [0, 0, 0, 0, 0, 0]
                       ]
            askServer(n, "resetGame")
        # 승부가 나지 않았을 경우
        counter = 1

        while counter:
            clock.tick(1)
            if set_round > 5:
                msg = "animFinish,1," + str(p.x) + "," + str(p.y)
                temp = str(n.send(msg))
                if temp.startswith("start_"):
                    tilemap[int(temp.split(",")[3])][int(temp.split(",")[2])] = 2
                    counter = 0

            else:
                temp = n.send(("animFinish,0"))
                if temp == "start_check,0":
                    counter = 0




main()
