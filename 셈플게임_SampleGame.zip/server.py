import socket
from _thread import *
import random

server = "192.168.56.1"
port = 5555

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    s.bind((server, port))
except socket.error as e:
    str(e)

s.listen(2)
print("Waiting for a connection, Server Started")  # 서버 작동 시작

# 서버가 가지고 있는 게임 관련 변수.
pos = ["position,0,2", "position,5,2"]
cards = [[0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0]]
anim_finish = [0, 0]
card_finish = [0, 0]
tilemap = [[0, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 0]
           ]
next_coll = [-1, -1]
player_pos = [[0, 2], [5, 2]]
player_exited = 0
player_exit = [0, 0]

def read_pos(msg, p1):  # 플레이어로부터 입력받은 메세지를 분석하고 서버의 대응을 결정하는 함수
    # str[문자열 변수]: 플레이어의 입력   |   p1[정수형 변수]: 메세지를 보낸 플레이어의 번호
    global player_exited, card_finish, anim_finish, next_coll, p2_pos, player_pos, tilemap, player_exit

    print("[", str(p1), "] Received: ", msg)  # 출력 예시 [ 0 ] Received: finish,0,1,0
    temp = msg.split(",")
    # 메세지의 종류를 파악
    # 클라이언트에서는
    # n.send("[메세지의 종류],[전달하고 싶은 데이터],[데이터],[데이터]") 와 같은 명령어를 이용해 데이터를 서버에 전송할 수 있다.
    try:
        if player_exited:
            return "you_win"
        else:
            p2 = (p1 + 1) % 2

            if temp[0] == "cardFinish":  # received : cardFinish,3,2,0,0,0,0,0,0
                anim_finish = [0, 0]
                for i in range(8):
                    cards[p1][i] = int(temp[i + 1])
                card_finish[p1] = 1
                if card_finish == [1, 1]:
                    p2_card = "start_anim," + str(cards[p2][0]) + "," + str(cards[p2][1]) + "," + str(
                        cards[p2][2]) + "," + \
                              str(cards[p2][3]) + "," + str(cards[p2][4]) + "," + str(cards[p2][5]) + "," + str(
                        cards[p2][6]) + "," + str(cards[p2][7])
                    return p2_card  # sending :start_anim,3,2,0,0,0,0,0,0
                else:
                    return "wait"

            elif temp[0] == "animFinish":
                card_finish = [0, 0]
                if temp[1] == "0":  # received : animFinish,0
                    anim_finish[p1] = 1
                    if anim_finish == [1, 1]:
                        return str("start_check,0")  # start_check, [collapse] , [x],[y]
                    else:
                        return "wait"
                elif temp[1] == "1":  # received : animFinish,1,pos
                    anim_finish[p1] = 1
                    player_pos[p1] = [int(temp[2]), int(temp[3])]
                    if anim_finish == [1, 1]:
                        if next_coll == [-1, -1]:
                            while True:
                                coll_temp = [int(random.randrange(0, 6)), int(random.randrange(0, 5))]
                                if player_pos[0] != coll_temp and player_pos[1] != coll_temp and tilemap[coll_temp[0]][
                                    coll_temp[1]] != 2:
                                    next_coll = coll_temp
                                    break
                            tilemap[next_coll[1]][next_coll[0]] = 2
                            return "start_check,1," + make_pos(next_coll)
                        else:
                            print(p1, " : receive", )
                            temp = "start_check,1," + make_pos(next_coll)
                            next_coll = [-1, -1]
                            return temp
                    else:
                        return "wait"
                else:
                    return "disconnect"

            elif temp[0] == "playerExit":
                player_exited = 1
                return "disconnect"

            elif temp[0] == "severCheck":
                return "online"
            elif temp[0] == "cardCheck":
                if card_finish[0] == 1 or card_finish[1] == 1:
                    return "isFinished"
                else:
                    return "wait"
            elif temp[0] == "cardRefresh":
                card_finish[p1] = 0
                return "wait"
            elif temp[0] == "resetGame":
                anim_finish = [0, 0]
                card_finish = [0, 0]
                tilemap = [[0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0]
                           ]
                next_coll = [-1, -1]
                player_pos = [[0, 2], [5, 2]]
                return "finish"
            elif temp[0] == "collapse":
                tilemap[int(temp[1])][int(temp[2])] = 2
                return "wait"
            else:
                return "error"
    except:
        print("Lost connection")
        conn.close()

def make_pos(tup):
    return str(tup[0]) + "," + str(tup[1])


def threaded_client(conn, player):  # 클라이언트 각각에 대해 실행된다.

    # 각각의 클라이언트에 대한 초기화 부분
    global p1_pos, p2_pos, tilemap, next_coll, anim_finish, card_finish, player_exited
    conn.send(str.encode(pos[player]))  # 연결이 완료된 플레이어에게 위치를 지정
    print(pos[player])
    reply = ""

    while True:  # 메세지 반복 확인 및 read_pos 함수에서 결정한 반응 보내기
        try:
            reply = read_pos(conn.recv(2048).decode(), player)
        except:
            print("lost connection")
            conn.close()

        conn.sendall(str.encode(reply))
        print("[", str(player), "]", "Sending : ", reply)  # 출력 예시 [ 1 ] Send: you_win


# ============================================================================================ 실제 서버가 실행되는 부분
currentPlayer = 0
while True:

    conn, addr = s.accept()
    print("Connected to:", addr, currentPlayer)

    start_new_thread(threaded_client, (conn, currentPlayer))
    print(player_exit)
    player_exit[currentPlayer] = 1
    currentPlayer += 1

